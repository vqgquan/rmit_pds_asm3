RMIT COSC2999
Assignment 3:

Group 6:
Vu Quoc Gia Quan - s3927120
William TRAN - s4196432  
Sébastien MASSY - s4196435

Install all dependencies in requirements.txt